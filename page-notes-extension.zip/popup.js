const els = {
  settingsToggle: document.getElementById('settingsToggle'),
  settingsPanel: document.getElementById('settingsPanel'),
  apiKey: document.getElementById('apiKey'),
  model: document.getElementById('model'),
  vaultName: document.getElementById('vaultName'),
  noteStyle: document.getElementById('noteStyle'),
  blockedSites: document.getElementById('blockedSites'),
  saveSettings: document.getElementById('saveSettings'),
  extractBtn: document.getElementById('extractBtn'),
  status: document.getElementById('status'),
  previewPanel: document.getElementById('previewPanel'),
  previewMeta: document.getElementById('previewMeta'),
  extractedText: document.getElementById('extractedText'),
  sendBtn: document.getElementById('sendBtn'),
  cancelExtractBtn: document.getElementById('cancelExtractBtn'),
  noteText: document.getElementById('noteText'),
  saveObsidianBtn: document.getElementById('saveObsidianBtn'),
  copyBtn: document.getElementById('copyBtn'),
  downloadBtn: document.getElementById('downloadBtn'),
  historyList: document.getElementById('historyList'),
};

const DEFAULT_BLOCKED_SITES = [
  'accounts.google.com',
  'login.microsoftonline.com',
  'login.live.com',
  'id.apple.com',
  'chase.com',
  'bankofamerica.com',
  'wellsfargo.com',
  'paypal.com',
  'irs.gov',
  'healthcare.gov',
];

// Non-http(s) schemes never make sense to extract from and are always blocked,
// regardless of the user's own blocked-sites list.
const ALWAYS_BLOCKED_PROTOCOLS = ['chrome:', 'chrome-extension:', 'vivaldi:', 'edge:', 'about:', 'file:'];

let currentMeta = { title: '', url: '' };
let pendingPage = null;

function setStatus(msg, show = true) {
  els.status.textContent = msg;
  els.status.classList.toggle('hidden', !show);
}

function slugify(str) {
  return (str || 'note')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 60) || 'note';
}

function uniqueFileBase() {
  const now = new Date();
  const stamp = now.toISOString().slice(0, 16).replace(/[-:T]/g, '').replace(/(\d{8})(\d{4})/, '$1-$2');
  return `${stamp}-${slugify(currentMeta.title)}`;
}

async function loadSettings() {
  const s = await chrome.storage.local.get(['apiKey', 'model', 'vaultName', 'noteStyle', 'blockedSites']);
  if (s.apiKey) els.apiKey.value = s.apiKey;
  if (s.model) els.model.value = s.model;
  if (s.vaultName) els.vaultName.value = s.vaultName;
  if (s.noteStyle) els.noteStyle.value = s.noteStyle;
  els.blockedSites.value = (s.blockedSites || DEFAULT_BLOCKED_SITES).join('\n');
}

async function saveSettings() {
  const blockedSites = els.blockedSites.value
    .split('\n')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  await chrome.storage.local.set({
    apiKey: els.apiKey.value.trim(),
    model: els.model.value.trim() || 'nvidia/nemotron-3-super-120b-a12b:free',
    vaultName: els.vaultName.value.trim(),
    noteStyle: els.noteStyle.value,
    blockedSites,
  });
  els.settingsPanel.classList.add('hidden');
  setStatus('Settings saved.');
  setTimeout(() => setStatus('', false), 1500);
}

function isBlockedUrl(urlStr, blockedSites) {
  let url;
  try {
    url = new URL(urlStr);
  } catch {
    return true; // unparsable URL is not something we should touch
  }
  if (ALWAYS_BLOCKED_PROTOCOLS.includes(url.protocol)) return true;
  const host = url.hostname.toLowerCase();
  return blockedSites.some((pattern) => host === pattern || host.endsWith('.' + pattern));
}

// Runs inside the page itself via chrome.scripting.executeScript
function extractPageContent() {
  let method = 'body';
  let pick = document.querySelector('article');
  if (pick) method = 'article';
  else {
    pick = document.querySelector('main, [role="main"]');
    if (pick) method = 'main';
    else pick = document.body;
  }
  let text = (pick.innerText || '').replace(/\s+\n/g, '\n').trim();
  const fullLength = text.length;
  let truncated = false;
  if (text.length > 14000) {
    text = text.slice(0, 14000);
    truncated = true;
  }
  return { title: document.title, url: location.href, text, method, fullLength, truncated };
}

async function extractPage() {
  const s = await chrome.storage.local.get('blockedSites');
  const blockedSites = s.blockedSites || DEFAULT_BLOCKED_SITES;

  els.extractBtn.disabled = true;
  setStatus('Checking page…');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (isBlockedUrl(tab.url, blockedSites)) {
      setStatus('This page is on your blocked-sites list (or is a browser-internal page). Extraction cancelled.');
      return;
    }

    setStatus('Reading page…');
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPageContent,
    });

    pendingPage = result;
    currentMeta = { title: result.title, url: result.url };

    const sizeNote = result.truncated
      ? `${result.text.length} of ${result.fullLength} chars (truncated)`
      : `${result.text.length} chars`;
    els.previewMeta.textContent = `${result.title || '(untitled)'} · via "${result.method}" · ${sizeNote}`;
    els.extractedText.value = result.text;
    els.previewPanel.classList.remove('hidden');
    setStatus('Extracted. Review the text, then send it.');
  } catch (err) {
    setStatus('Error: ' + err.message);
  } finally {
    els.extractBtn.disabled = false;
  }
}

async function sendToAI() {
  const s = await chrome.storage.local.get(['apiKey', 'model', 'noteStyle']);
  if (!s.apiKey) {
    setStatus('Add your OpenRouter API key in Settings first.');
    els.settingsPanel.classList.remove('hidden');
    return;
  }
  if (!pendingPage) {
    setStatus('Extract a page first.');
    return;
  }

  els.sendBtn.disabled = true;
  setStatus('Asking the model…');

  try {
    const page = { ...pendingPage, text: els.extractedText.value };
    const response = await chrome.runtime.sendMessage({
      type: 'SUMMARIZE',
      apiKey: s.apiKey,
      model: s.model || 'nvidia/nemotron-3-super-120b-a12b:free',
      style: s.noteStyle || 'summary',
      page,
    });

    if (response?.error) {
      setStatus('Error: ' + response.error);
    } else {
      els.noteText.value = response.markdown;
      els.previewPanel.classList.add('hidden');
      pendingPage = null;
      setStatus('Done. Edit freely before saving.');
      await addToHistory(currentMeta, response.markdown);
    }
  } catch (err) {
    setStatus('Error: ' + err.message);
  } finally {
    els.sendBtn.disabled = false;
  }
}

function cancelExtraction() {
  pendingPage = null;
  els.previewPanel.classList.add('hidden');
  setStatus('', false);
}

async function addToHistory(meta, markdown) {
  const { notes = [] } = await chrome.storage.local.get('notes');
  notes.unshift({ ...meta, markdown, date: new Date().toISOString() });
  await chrome.storage.local.set({ notes: notes.slice(0, 20) });
  renderHistory(notes.slice(0, 5));
}

async function renderHistory(preloaded) {
  const notes = preloaded || (await chrome.storage.local.get('notes')).notes || [];
  els.historyList.innerHTML = '';
  notes.slice(0, 5).forEach((n) => {
    const li = document.createElement('li');
    const titleSpan = document.createElement('span');
    titleSpan.className = 'note-title';
    titleSpan.textContent = n.title || 'Untitled';
    const metaSpan = document.createElement('span');
    metaSpan.className = 'note-meta';
    metaSpan.textContent = new Date(n.date).toLocaleString();
    li.replaceChildren(titleSpan, metaSpan);
    li.addEventListener('click', () => {
      els.noteText.value = n.markdown;
      currentMeta = { title: n.title, url: n.url };
    });
    els.historyList.appendChild(li);
  });
}

function yamlQuote(str) {
  // Double-quoted YAML scalar: escape backslashes and double quotes.
  return `"${String(str).replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
}

function buildFrontmatter() {
  const date = new Date().toISOString().slice(0, 10);
  return `---
title: ${yamlQuote(currentMeta.title || 'Untitled')}
source: ${yamlQuote(currentMeta.url || '')}
date: ${date}
tags: [web-notes]
---

`;
}

els.saveObsidianBtn.addEventListener('click', async () => {
  const { vaultName } = await chrome.storage.local.get('vaultName');
  if (!vaultName) {
    setStatus('Set your Obsidian vault name in Settings first.');
    els.settingsPanel.classList.remove('hidden');
    return;
  }
  const fileName = uniqueFileBase();
  const content = buildFrontmatter() + els.noteText.value;
  const uri = `obsidian://new?vault=${encodeURIComponent(vaultName)}&name=${encodeURIComponent(
    fileName
  )}&content=${encodeURIComponent(content)}`;
  chrome.tabs.create({ url: uri });
});

els.copyBtn.addEventListener('click', async () => {
  const content = buildFrontmatter() + els.noteText.value;
  await navigator.clipboard.writeText(content);
  setStatus('Copied to clipboard.');
  setTimeout(() => setStatus('', false), 1500);
});

els.downloadBtn.addEventListener('click', () => {
  const content = buildFrontmatter() + els.noteText.value;
  const fileName = `${uniqueFileBase()}.md`;
  const dataUrl = 'data:text/markdown;charset=utf-8,' + encodeURIComponent(content);
  chrome.downloads.download({ url: dataUrl, filename: fileName, saveAs: false });
});

els.settingsToggle.addEventListener('click', () => {
  els.settingsPanel.classList.toggle('hidden');
});
els.saveSettings.addEventListener('click', saveSettings);
els.extractBtn.addEventListener('click', extractPage);
els.sendBtn.addEventListener('click', sendToAI);
els.cancelExtractBtn.addEventListener('click', cancelExtraction);

loadSettings();
renderHistory();
