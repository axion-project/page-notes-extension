const STYLE_PROMPTS = {
  summary: 'Write a concise 3-6 sentence summary, then a short "Why it matters" line.',
  detailed: 'Write detailed structured notes with headings covering the main sections of the page, preserving key facts, figures, and names.',
  bullets: 'Write the content as a tight bulleted list of the key points only, no prose paragraphs.',
};

async function callOpenRouter({ apiKey, model, style, page }) {
  const instruction = STYLE_PROMPTS[style] || STYLE_PROMPTS.summary;
  const systemPrompt = `You turn webpages into clean Markdown notes for an Obsidian vault.
Rules:
- Output valid Markdown only, no code fences around the whole thing.
- Use ## headings, and [[wikilink]] style for any clearly notable named entities, tools, or concepts worth linking later.
- ${instruction}
- Do not repeat the raw URL in the body; it is already stored separately.`;

  const userPrompt = `Page title: ${page.title}\nURL: ${page.url}\n\nPage content:\n${page.text}`;

  const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://aedininsight.com',
      'X-Title': 'Page Notes Extension',
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.4,
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`OpenRouter ${res.status}: ${text.slice(0, 200)}`);
  }

  const data = await res.json();
  const markdown = data?.choices?.[0]?.message?.content;
  if (!markdown) throw new Error('No content returned by model.');
  return markdown;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== 'SUMMARIZE') return false;

  callOpenRouter(msg)
    .then((markdown) => {
      chrome.storage.local.set({ lastDraft: { markdown, page: msg.page, date: Date.now() } });
      sendResponse({ markdown });
    })
    .catch((err) => sendResponse({ error: err.message }));

  return true; // keep the message channel open for the async response
});
